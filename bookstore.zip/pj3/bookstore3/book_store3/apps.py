from django.apps import AppConfig


class BookStore3Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'book_store3'
